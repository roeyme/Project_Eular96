import numpy as np
import math
import Toolbox

# BoardState
"""
The class 'BoardState' is a toolbox that provides an efficient and transparent
analysis of soduko boards, including executing basic actions. 
It is used to efficiently and easily implementing soduko solvers,
in addition to partially unify the implementation of different solvers.
"""


class BoardState:
    def __init__(self, board):
        """
        'board - the targeted soduko board
        'currentDecisionsNumber' - the number of currently applied decisions
        'statementsList' - the stack of the currently asserted statements
        'assignmentsMatrix' - matrix such that assignmentsMatrix[i][j][val] is
        1 if blank (i,j) can get the value 'val', and 0 otherwise.
        for efficiency reasons, matrix[i][j][0] contains the number of possible
        values for blank (i,j). If blank (i,j) was selected then matrix[i][j][0]
        is increased by the number of blanks of one row.
        'immidiateDecisions' - the queue of immidiate decisions, i.e., a list
        with elements of the form (idx, val) where 'idx' is an index of a blank
        s.t., 'val' is its only possible value.
        """
        self.board = board
        self.currentDecisionsNumber = 0
        self.len = board.shape[0]
        self.localGridLen = int(math.sqrt(self.len))
        self.statementsList = []
        self.assignmentsMatrix = np.ones((self.len, self.len, self.len + 1), dtype=np.int8)
        self.assignmentsMatrix[:, :, 0] = self.len
        self.immidiateDecisions = []
        for i in range(self.len):
            for j in range(self.len):
                currVal = board[i][j]
                if currVal != 0:
                    self.decide((i, j), currVal)

    def getCurrentDecisionsNumber(self):
        return self.currentDecisionsNumber

    def getStatementsNum(self):
        return len(self.statementsList)

    def getCurrBoard(self):
        return self.board

    def findMin(self):
        """
        returns the idx of the blank with minimal number of possible values, in
        addition to one of its possible values.
        """
        minPos = np.argmin(self.assignmentsMatrix[:, :, 0])
        row = math.floor(minPos / self.len)
        col = minPos % self.len
        minIdx = (row, col)
        minVal = Toolbox.findPossibleVal(self.assignmentsMatrix[minIdx][1:])
        return minIdx, minVal

    def decide(self, idx, val, memorize=False):
        """
        apply the decision - board[idx] = val - and apply immidiate statements
        as long as there are any
        """
        self.assignmentsMatrix[idx][0] += (self.len + 1)
        self.currentDecisionsNumber += 1
        self.board[idx] = val
        if memorize:
            statement = Statement(idx, val, True)
            self.statementsList.append(statement)
        return self.deduce(idx, val, memorize)

    def eliminate(self, idx, val, memorize=False):
        """
        apply the statement 'board[idx] = val' and returns blank 'idx' is left
        with no possible values. If blank 'idx' remains with one possible value,
        then, the resultant immidiate decision is added to
        self.immidiateDecisions
        """
        self.assignmentsMatrix[idx][val] = 0
        self.assignmentsMatrix[idx][0] -= 1
        if memorize:
            statement = Statement(idx, val, False)
            self.statementsList.append(statement)
        if self.assignmentsMatrix[idx][0] == 0:
            return True
        if self.assignmentsMatrix[idx][0] == 1:
            newVal = Toolbox.findPossibleVal(self.assignmentsMatrix[idx][1:])
            self.immidiateDecisions.append((idx, newVal))
        return False

    def undoDecision(self, idx):
        self.assignmentsMatrix[idx][0] -= (self.len + 1)
        self.board[idx] = 0
        self.currentDecisionsNumber -= 1

    def undoElimination(self, idx, val):
        self.assignmentsMatrix[idx][val] = 1
        self.assignmentsMatrix[idx][0] += 1

    def undoStatement(self, statement):
        idx, val, sign = statement.getStatement()
        if sign:
            self.undoDecision(idx)
        else:
            self.undoElimination(idx, val)

    def deduce(self, idx, val, memorize=False):
        """
         'deduce immidiate statements that stem from the decision
         'board[idx] = val', until there are none
        """
        i, j = idx
        # eliminate from row
        for colIndex in range(self.len):
            if self.assignmentsMatrix[i][colIndex][val] and \
                    self.board[i][colIndex] == 0:
                newIdx = (i, colIndex)
                if self.eliminate(newIdx, val, memorize):
                    return True

        # eliminate from column
        for rowIndex in range(self.len):  # eliminate from rows
            if self.assignmentsMatrix[rowIndex][j][val] and \
                    self.board[rowIndex][j] == 0:
                newIdx = (rowIndex, j)
                if self.eliminate(newIdx, val, memorize):
                    return True

        # eliminate from local grid
        """
        the next line could be computed for each blank seperately at the
        beginning, but due to simplicity reasons and since its O(1), we dont
        do it here.
        """
        leftRow, rightRow, leftCol, rightCol = \
            self.findLocalGridVertices(idx, self.localGridLen)
        for localGridRow in range(leftRow, rightRow):
            for localGridCol in range(leftCol, rightCol):
                if self.assignmentsMatrix[localGridRow][localGridCol][val] and \
                        self.board[localGridRow][localGridCol] == 0:
                    newIdx = (localGridRow, localGridCol)
                    if self.eliminate(newIdx, val, memorize):
                        return True
        return self.executeImmidiateDecisions(memorize)

    def executeImmidiateDecisions(self, memorize=False):
        while self.immidiateDecisions:
            idx, val = self.immidiateDecisions.pop(0)
            if self.decide(idx, val, memorize):
                return True
        return False

    @staticmethod
    def findLocalGridVertices(idx, n):
        """
        finds the indices representing the four vertices of the local grid containing
        the blank 'idx' in a board of size 'n'.
        """
        idx = np.array(idx)
        lh = idx - (idx % n)
        rl = lh + n
        return lh[0], rl[0], lh[1], rl[1]

    def backStep(self, idx):
        """
        reverse to the time right after statement 'statementList[idx]' was
        executed, i.e., undo all statements that appear in index 'idx' or above
        in the statements stack
        """
        for statement in self.statementsList[idx:]:
            self.undoStatement(statement)
        self.statementsList = self.statementsList[:idx]
        self.immidiateDecisions = []


class Statement:
    def __init__(self, blank, val, sign):
        self.blank = blank
        self.val = val
        self.sign = sign

    def getStatement(self):
        return self.blank, self.val, self.sign
