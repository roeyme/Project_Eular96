"""This module provides a tool box to check solutions of soduko boards"""
import Toolbox
import math
import numpy as np

def checkSolutions(listOfBoards, listOfSolutions):
    listOfResults = []
    for idx, board in enumerate(listOfBoards):
        solution = listOfSolutions[idx]
        assert Toolbox.checkIfValidSodukoBoard(board), f'board {idx} is invalid'
        assert Toolbox.checkIfValidSodukoBoard(solution), f'solution {idx} is invalid'
        listOfResults.append(checkSolution(board, solution))
    return listOfResults


def checkSolution(board, solution):
    # check if 'solution' board is consistent with 'board'
    if board.shape != solution.shape:
        print('jhh')
        return False
    elif (board[board != 0] != solution[board != 0]).any():
        print(board)
        print(solution)
        return False
    n = board.shape[0]
    np.arange(n+1)
    # check if 'solution' is legal
    for row in board:  # check rows
        if np.unique(row).shape[0] < row.shape[0]:
            return False
    for row in board.T:  # check columns
        if np.unique(row).shape[0] < row.shape[0]:
            return False
    # check localGrids
    localGridLen = int(math.sqrt(n))
    localGridsList = Toolbox.blockshaped(board, localGridLen, localGridLen)
    for localGrid in localGridsList:
        if np.unique(localGrid).size < np.array(localGrid).size:
            return False
    return True
