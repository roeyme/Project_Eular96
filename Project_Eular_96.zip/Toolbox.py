import numpy as np
import math
"""
# ToolBox

The next module contains general methods that are used in building the 
"""

"""
given an array with indicators for possible values, 
it returns an error if there is more then one option, otherwise, it returns
the sole option
"""


def findPossibleVal(valsIndicator):
    for val in range(valsIndicator.shape[0]):
        if valsIndicator[val] == 1:
            return val + 1
    return False

def blockshaped(arr, nrows, ncols):
    """
    Return an array of shape (n, nrows, ncols) where
    n * nrows * ncols = arr.size

    If arr is a 2D array, the returned array should look like n subblocks with
    each subblock preserving the "physical" layout of arr.
    """
    h, w = arr.shape
    assert h % nrows == 0, f"{h} rows is not evenly divisible by {nrows}"
    assert w % ncols == 0, f"{w} cols is not evenly divisible by {ncols}"
    return (arr.reshape(h // nrows, nrows, -1, ncols)
            .swapaxes(1, 2)
            .reshape(-1, nrows, ncols))


def checkIfValidSodukoBoard(board):
    """
    checks if the object 'board' represents a valid sudoko problem
    """
    if isinstance(board, np.ndarray):
        n = board.shape[0]
        if board.ndim == 2:
            if board.shape[1] == n and n == np.floor(math.sqrt(n)) ** 2 \
                    and np.logical_and(board >= 0, board <= n).all() \
                    and (board == np.floor(board)).all():
                return True
    return False


def readBoardsFromFile(boardsFile):
    newBoardsList = []
    with open(boardsFile) as f:
        lines = f.readlines()
        board = []
        for line in lines:
            line = line.replace(' ', '').replace('\n', '')
            if not line.isnumeric():
                if board:
                    board = np.array(board, dtype=np.int8)
                    newBoardsList.append(board)
                    board = []
            else:
                board.append(list(line))
        board = np.array(board, dtype=np.int8)
        newBoardsList.append(board)
        return newBoardsList
