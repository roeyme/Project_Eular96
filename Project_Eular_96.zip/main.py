from BoardsManager import BoardsManager
import numpy as np

"""The following script solves the Eular96 task"""
source = 'soduko.txt'
menager = BoardsManager(source)
menager.solveBoards(preserveOriginalBoards=False)
solvedBoards = np.array(menager.getSolutions()[0])
ans = np.sum(solvedBoards[:,:,:3] * np.array([100,10,1]))
print(f'the answer is {ans}')
