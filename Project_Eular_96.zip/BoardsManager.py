"""# BoardsManager
This class BoardsManager is used direclty by the end-user.
It handles reading, solving, storing and displaying
Soduko boards.
"""
from SodukoSolver import SodukoSolver
import copy
import Toolbox
import numpy as np


class BoardsManager:
    def __init__(self, source=None):
        self.boardsList = []
        self.solutions = []
        self.resultsList = []
        if source is not None:
            self.readBoards(source)

    def readBoards(self, source):
        """
        reads boards to a list of np.arrays from 'source'. 'source can be either
        a list of np.arrays, or a file path. if its the latter, then the file
        should be with the required format (that of the 'soduko.txt' file).
        """
        if isinstance(source, str):
            newBoards = self.readBoardsFromFile(source)
        elif isinstance(source, list):
            newBoards = source
        elif isinstance(source, np.ndarray):
            newBoards = [source]
        else:
            raise Exception('recieved an invalid type of source')
        for idx, board in enumerate(newBoards):
            assert Toolbox.checkIfValidSodukoBoard(board), \
                f'board {idx} is not a invalid soduko board'
        self.boardsList += newBoards

    @staticmethod
    def readBoardsFromFile(boardsFile):
        newBoardsList = []
        with open(boardsFile) as f:
            lines = f.readlines()
            board = []
            for line in lines:
                line = line.replace(' ', '').replace('\n', '')
                if not line.isnumeric():
                    if board:
                        board = np.array(board, dtype=np.int8)
                        newBoardsList.append(board)
                        board = []
                else:
                    board.append(list(line))
            board = np.array(board, dtype=np.int8)
            newBoardsList.append(board)
            return newBoardsList

    def getSolutions(self, indices=None):
        if indices is None:
            indices = range(len(self.solutions))
        for i in indices:
            assert isinstance(i, int), \
                f'index {i} is not integer'
            assert np.abs(i) <= len(self.solutions), \
                f'index {i} is out of range'
        return self.solutions, self.resultsList

    def displaySolutions(self, indices=None):
        if indices is None:
            indices = range(len(self.solutions))
        for i in indices:
            assert isinstance(i, int), \
                f'index {i} is not integer'
            assert np.abs(i) <= len(self.solutions), \
                f'index {i} is out of range'
            print(f'The solution of board {i} is\n{self.solutions}')

    def solveBoards(self, preserveOriginalBoards=True):
        self.solutions = []
        self.resultsList = []
        for board in self.boardsList:
            if preserveOriginalBoards:
                boardCpy = copy.deepcopy(board)
                CurrSolver = SodukoSolver(boardCpy)
            CurrSolver = SodukoSolver(board)
            res, solution = CurrSolver.getSolution()
            self.resultsList.append(res)
            self.solutions.append(solution)
