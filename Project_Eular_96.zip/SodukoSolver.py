"""# SodukoSolver
This class is not accessed by the end-user and provides
a toolbox of soduko solvers that use the 'boardAnalyzer' module
"""
from BoardState import BoardState


class SodukoSolver:
    """
    A toolbox of soduko solvers that uses the 'boardAnalyzer' module.
    currently, it provides only a single solver, but using the modular design,
    more solutions can be easily added.
    """
    def __init__(self, board):
        self.n = board.shape[0]
        self.blanksNum = self.n**2
        self.board = board
        self.boardAnalyzer = BoardState(board)

    def getSolution(self):
        if self.solve():
            return True, self.boardAnalyzer.board
        return False, -1

    def solve(self, numOfStatements=0):
        """
        until solution is found, 'guess' a value for some blank with minimal
        number of possible values (to reach contradictions faster) and deduce
        all of the immediate statements. If a
        contradiction is encountered, then go back to the previous guess point
        and guess a different value for the same index.
        """
        if self.boardAnalyzer.getCurrentDecisionsNumber() < self.blanksNum:
            minIdx, minVal = self.boardAnalyzer.findMin()
            for val in range(1, self.n+1):
                if self.boardAnalyzer.assignmentsMatrix[minIdx][val]:
                    if not self.boardAnalyzer.decide(minIdx, val, memorize=True):
                        if self.solve(self.boardAnalyzer.getStatementsNum()):
                            return True
                    self.boardAnalyzer.backStep(numOfStatements)
            return False
        return True
